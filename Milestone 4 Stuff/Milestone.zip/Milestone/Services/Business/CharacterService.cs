﻿using Milestone.Models;
using Milestone.Services.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Milestone.Services.Business
{

    public class CharacterService
    {

        public bool createCharacter(Character character)
        {
            Console.WriteLine(character.getCharacterName(), character.getHealth());

            CharacterDAO cao = new CharacterDAO();
            cao.characterCreation(character);

            return true;
        }

        public bool findCharacterById(int id)
        {

            // CharacterDAO cao = new CharacterDAO();

            //return cao.register(id);
            return false;
        }

    }
}