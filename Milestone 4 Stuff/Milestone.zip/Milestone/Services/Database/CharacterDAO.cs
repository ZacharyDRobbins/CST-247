﻿using Milestone.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Milestone.Services.Database
{
    public class CharacterDAO
    {
        string dbconn = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Test;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public bool register(User user)
        {

            bool result = false;

            try
            {
                // prepare the INSERT statement
                string query = "INSERT INTO dbo.Users (USERNAME, PASSWORD) VALUES (@Username, @Password)";

                // Create connection and command
                using (SqlConnection cn = new SqlConnection(dbconn))
                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    //parameters values
                    cmd.Parameters.Add("@Username", SqlDbType.VarChar, 50).Value = user.Username;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 50).Value = user.Password;

                    // Open the connection and execute the insert method afterwards close the connection
                    cn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 1)
                        result = true;
                    else
                        result = false;
                    cn.Close();
                }

            }
            catch (SqlException e)
            {

                throw e;
            }

            // Return result of register
            return result;
        }

        public bool characterCreation(Character character)
        {

            bool result = false;
            int characterId = 6;
            int testPlayerId = 6;
            try
            {
                // prepare the INSERT statement
                string query = "INSERT INTO dbo.Characters (Id, CHAR_NAME, CHAR_CLASS, CHAR_HEALTH, CHAR_ATTACK, CHAR_WEAPON_TYPE, PLAYER_ID) VALUES (@characterId, @characterName, @classChoice, @health, @attack, @weaponType, @testPlayerId)";

                // Create connection and command
                using (SqlConnection cn = new SqlConnection(dbconn))
                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    //parameters values
                    cmd.Parameters.Add("@characterId", SqlDbType.Int).Value = characterId;
                    cmd.Parameters.Add("@characterName", SqlDbType.VarChar, 50).Value = character.getCharacterName();
                    cmd.Parameters.Add("@classChoice", SqlDbType.VarChar, 50).Value = character.getClassChoice();
                    cmd.Parameters.Add("@health", SqlDbType.Int).Value = character.setHealth(character.classChoice);
                    cmd.Parameters.Add("@attack", SqlDbType.Int).Value = character.setAttack(character.classChoice);
                    cmd.Parameters.Add("@weaponType", SqlDbType.VarChar, 50).Value = character.setWeaponType(character.classChoice);
                    cmd.Parameters.Add("@testPlayerId", SqlDbType.Int).Value = testPlayerId;

                    // Open the connection and execute the insert method afterwards close the connection
                    cn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 1)
                        result = true;
                    else
                        result = false;
                    cn.Close();
                }

            }
            catch (SqlException e)
            {

                throw e;
            }

            // Return result of register
            return result;
        }
    

        public bool findCharacterById(int id)
        {

            bool result = false;

            try
            {
                //prepare the SELECT statement
                string query = "SELECT * FROM dbo.Characters WHERE id=@id";
                using (SqlConnection cn = new SqlConnection(dbconn))
                using (SqlCommand cmd = new SqlCommand(query, cn))

                {
                    //set parameter values
                    //cmd.Parameters.

                    //"@characterId", "@characterName", "@classChoice", "@health", "@attack","@weaponType", "@testPlayerId", 

                    //open connection then execute the SELECT statement and close the connection
                    //cn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                        result = true;
                    else
                        result = false;

                    cn.Close();
                }
                //return the result of findByUser
                return result;
            }
            catch (Exception e)
            {
                return result;
            }
        }

    }

}