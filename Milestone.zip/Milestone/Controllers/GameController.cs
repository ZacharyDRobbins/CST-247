﻿using Milestone.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Milestone.Controllers
{
    public class GameController : Controller
    {
        // GET: Game
        [HttpGet]
        public ActionResult Index()
        {
            return View("Home");
        }
         
        public List<Character> GetEmpList()
        {
            List<Character> testList = new List<Character>()
            {
                new Character { characterId=1, characterName="Magnus Chase", classChoice="Mage", health=100, attack=50, weaponType="Staff"},
                new Character { characterId=2, characterName="Annabeth Chase", classChoice="Archer", health=120, attack=33, weaponType="Bow"},
            };

            return testList;
        }

    }
}