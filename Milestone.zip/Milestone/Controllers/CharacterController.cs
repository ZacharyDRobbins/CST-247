﻿using Milestone.Models;
using Milestone.Services.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Milestone.Controllers
{
    public class CharacterController : Controller
    {
        // GET: Character
        public ActionResult Index()
        {
            return View();
        }

        //POST : Character
        [HttpPost]
        public ActionResult CharacterCreation(Character model)
        {
            Console.WriteLine("Entering character creation . . .");
            model.createNewCharacter(model.characterName, model.classChoice);
            Console.WriteLine(model.characterName);
            Console.WriteLine(model.classChoice);
            Console.WriteLine(model.health);
            Console.WriteLine(model.attack);
            Console.WriteLine(model.weaponType);
            Console.WriteLine("^^^ New Character Info above ^^^");

            CharacterService cao = new CharacterService();
            bool result = cao.createCharacter(model);
            if (result == true)
            {
                ViewData["character"] = model;
                return View("~/Views/Game/_CharacterStats.cshtml");
            }
            else
                return View("LoginFailed");

        }

    }
}